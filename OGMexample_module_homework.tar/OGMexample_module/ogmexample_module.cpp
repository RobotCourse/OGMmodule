#include "ogmexample_module.h"


OGMexample_module::OGMexample_module()
{
}
