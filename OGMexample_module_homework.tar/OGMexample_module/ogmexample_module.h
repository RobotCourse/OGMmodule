#ifndef OGMEXAMPLE_MODULE_H
#define OGMEXAMPLE_MODULE_H

#include "ogmexample_module_global.h"

class OGMEXAMPLE_MODULESHARED_EXPORT OGMexample_module
{

public:
    OGMexample_module();
};

#endif // OGMEXAMPLE_MODULE_H
